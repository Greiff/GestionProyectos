/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Material;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class MaterialSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Material obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into materiales values(?,?,?)");
            st.setInt(1, obj.getId_mat());
            st.setString(2, obj.getNombre());
            st.setDouble(3, obj.getCosto_und());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Material obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update materiales set nombre=?,costo_und=? where id_mat=?");
            
            st.setString(1, obj.getNombre());
            st.setDouble(2, obj.getCosto_und());
            st.setInt(3, obj.getId_mat());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM materiales  WHERE id_mat = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Material> readAll() throws Exception {
        ArrayList<Material> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from materiales ");
            rs = st.executeQuery();

            while (rs.next()) {
                Material emp = new Material(rs.getInt(1), rs.getString(2), rs.getDouble(3));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

    public Material read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Material obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM materiales  WHERE id_mat = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Material(rs.getInt(1), rs.getString(2), rs.getDouble(3));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM materiales  WHERE NOMBRE like concat(concat('%',?),'%')");
                st.setString(1, palabra);
                st.setString(2, palabra);
            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM materiales  WHERE id_mat=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[3];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDouble(3);
                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT * "
                    + "from materiales ");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[3];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDouble(3);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    
    public void actualizarDatos() {
        CallableStatement st;
        try {
            st=con.getConn().prepareCall("call actualizar_datos()");
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(MaterialSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
                 
    }

}
