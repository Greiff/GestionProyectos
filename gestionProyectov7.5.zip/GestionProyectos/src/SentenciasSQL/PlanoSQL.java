/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Plano;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class PlanoSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Plano obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into planos values(?,?,?,CURRENT_DATE,?,?)");
            st.setInt(1, obj.getId_plano());
            st.setString(2, obj.getVersion());
            st.setString(3, obj.getPlano());
            st.setInt(4, obj.getDni());
            st.setInt(5, obj.getId_proy());

            
            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean createSinProy(Plano obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into planos values(?,?,?,CURRENT_DATE,?,null)");
            st.setInt(1, obj.getId_plano());
            st.setString(2, obj.getVersion());
            st.setString(3, obj.getPlano());
            st.setInt(4, obj.getDni());
  

            
            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Plano obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update planos set version=?,plano=?,dni=?,id_proy=? where id_plano=?");
            
            st.setString(1, obj.getVersion());
            st.setString(2, obj.getPlano());
            st.setInt(3, obj.getDni());
            st.setInt(4, obj.getId_proy());
            st.setInt(5, obj.getId_plano());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean updateContrato(int keyPlano, int keyProy) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update planos set id_proy=? where id_plano=?");
            
            st.setInt(1,keyProy);
            st.setInt(2,keyPlano);

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean updateNull(int keyPlano) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update planos set id_proy=null where id_plano=?");
            
      
            st.setInt(1,keyPlano);

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
 

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM planos WHERE id_plano = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Plano> readAll() throws Exception {
        ArrayList<Plano> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from Planos");
            rs = st.executeQuery();

            while (rs.next()) {
                Plano emp = new Plano(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4),rs.getInt(5), rs.getInt(6));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

    public Plano read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Plano obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM planos WHERE id_plano = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Plano(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4),rs.getInt(5), rs.getInt(6));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM planos WHERE version like concat(concat('%',?),'%')");
                st.setString(1, palabra);
            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM planos WHERE id_plano=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[6];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getDate(4);
                obj[4] = rs.getInt(5);
                obj[5] = rs.getInt(6);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT * "
                    + "from planos");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[6];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getDate(4);
                obj[4] = rs.getInt(5);
                obj[5] = rs.getInt(6);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    
    public List<Object[]> mostrarTodoContrato(Object key) throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT p.id_plano,p.version,p.fech_crea, e.nombre "
                    + "from planos p, empleados e where p.dni = e.dni and p.id_proy=? ");
            st.setObject(1, key);
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[4];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getString(4);


                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
