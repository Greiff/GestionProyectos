/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Detalle_Partida;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class Detalle_PartidaSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Detalle_Partida obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into Detalle_Partidas values(?,?,?,?)");
            st.setFloat(1, obj.getMetraje());
            st.setFloat(2, obj.getCosto_parcial());
            st.setInt(3, obj.getId_part());
            st.setInt(4, obj.getId_presu());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Detalle_Partida obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update Detalle_Partidas set metraje=?,costo_parcial where id_part=? and id_presu=?");
            st.setFloat(1, obj.getMetraje());
            st.setFloat(2, obj.getCosto_parcial());
            st.setInt(3, obj.getId_part());
            st.setInt(4, obj.getId_presu());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object keyPart,Object keyPresu) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM Detalle_Partidas WHERE id_part=? and id_presu=?");
            st.setInt(1, Integer.valueOf(keyPart.toString()));
            st.setInt(2, Integer.valueOf(keyPresu.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean deleteAll(Object keyPresu) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM Detalle_Partidas WHERE id_presu=?");
        
            st.setInt(1, Integer.valueOf(keyPresu.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Detalle_Partida> readAll() throws Exception {
        ArrayList<Detalle_Partida> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from Detalle_Partidas");
            rs = st.executeQuery();

            while (rs.next()) {
                Detalle_Partida emp = new Detalle_Partida( rs.getFloat(1),rs.getFloat(2), rs.getInt(3), rs.getInt(4));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

    public Detalle_Partida read(Object keyPart,Object keyPresu) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Detalle_Partida obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM Detalle_Partidas WHERE id_part=? and id_presu=?");
            st.setInt(1, Integer.valueOf(keyPart.toString()));
            st.setInt(2, Integer.valueOf(keyPresu.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Detalle_Partida(rs.getFloat(1),rs.getFloat(2), rs.getInt(3), rs.getInt(4));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> mostrarTodoPresu(Object keyPresu) throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("select dp.id_part,p.nombre,dp.costo_parcial,dp.metraje,(dp.costo_parcial*dp.metraje)"
                    + "from detalle_partidas dp,partidas p where dp.id_part=p.id_part and dp.id_presu =?");
            st.setInt(1, Integer.valueOf(keyPresu.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[5];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getFloat(3);
                obj[3] = rs.getFloat(4);
                obj[4] = rs.getFloat(5);
                
                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    public void actualizarDatosPresu(Object key) {
        CallableStatement st1,st2;
        try {
            st1=con.getConn().prepareCall("call guardar_presupuesto_detalle(?)");
            st1.setObject(1,key);
            st1.executeUpdate();
            
            st2=con.getConn().prepareCall("call actualizar_datos_presupuesto(?)");
            st2.setObject(1,key);
            st2.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(MaterialSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
                 
    }

}
