/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Presupuesto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class PresupuestoSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Presupuesto obj) throws Exception {
        PreparedStatement st;
        try {    
                st = con.getConn().prepareStatement("insert into Presupuestos values(?,?,CURRENT_DATE,0,0,null,?)");
                st.setInt(1, obj.getId_presu());
                st.setString(2, obj.getVersion());
                st.setInt(3, obj.getDni());
            
            
            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Presupuesto obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update Presupuestos set version=?,fech_crea=current_date,impuesto=?,importe_total=?,dni=? where id_presu=?");
            
            st.setString(1, obj.getVersion());
            st.setFloat(2, obj.getImpuesto());
            st.setFloat(3, obj.getImporte_total());
            st.setInt(4, obj.getDni());
            st.setInt(5, obj.getId_presu());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean updateContrato(int keyPresu,int keyProy) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update Presupuestos set id_proy=? where id_presu=?");
           
            st.setInt(1, keyProy);
            st.setInt(2, keyPresu);
        
            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }
    
    public boolean updateNull(int keyPresu) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update Presupuestos set id_proy=null where id_presu=?");
           
    
            st.setInt(1, keyPresu);
        
            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM Presupuestos WHERE id_presu = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Presupuesto> readAll() throws Exception {
        ArrayList<Presupuesto> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from Presupuestos");
            rs = st.executeQuery();

            while (rs.next()) {
                Presupuesto emp = new Presupuesto(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getFloat(4), rs.getFloat(5), rs.getInt(6),rs.getInt(7));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    

    public Presupuesto read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Presupuesto obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM Presupuestos WHERE id_presu = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Presupuesto(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getFloat(4), rs.getFloat(5), rs.getInt(6),rs.getInt(7));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM Presupuestos WHERE version like concat(concat('%',?),'%')");
                st.setString(1, palabra);
            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM Presupuestos WHERE id_presu=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[7];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getFloat(4);
                obj[4] = rs.getFloat(5);
                obj[5] = rs.getInt(6);
                obj[6] = rs.getInt(7);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT * "
                    + "from Presupuestos");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[7];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getFloat(4);
                obj[4] = rs.getFloat(5);
                obj[5] = rs.getInt(6);
                obj[6] = rs.getInt(7);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    
    public List<Object[]> mostrarTodoContrato(Object key) throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT id_presu,version,fech_crea,importe_total "
                    + "from Presupuestos where id_proy = ?");
            st.setObject(1, key);
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[4];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getFloat(4);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
