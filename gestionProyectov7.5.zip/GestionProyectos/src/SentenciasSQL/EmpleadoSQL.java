/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Empleado;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class EmpleadoSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Empleado obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into empleados values(?,?,?,?,?,?,?,?,?)");
            st.setInt(1, obj.getDni());
            st.setString(2, obj.getNombre());
            st.setString(3, obj.getApellido());
            st.setString(4, obj.getTelefono());
            st.setString(5, obj.getDireccion());
            st.setDate(6, obj.getFechaNac());
            st.setString(7, obj.getUsuario());
            st.setString(8, obj.getPassword());
            st.setInt(9, obj.getSupDni());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Empleado obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update empleados set nombre=?,apellido=?,telefono=?,direcc=?,fech_nac=?,usuario=?,pass=?,sup_dni=? where dni=?");
            
            st.setString(1, obj.getNombre());
            st.setString(2, obj.getApellido());
            st.setString(3, obj.getTelefono());
            st.setString(4, obj.getDireccion());
            st.setDate(5, obj.getFechaNac());
            st.setString(6, obj.getUsuario());
            st.setString(7, obj.getPassword());
            st.setInt(8, obj.getSupDni());
            st.setInt(9, obj.getDni());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM empleados WHERE dni = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Empleado> readAll() throws Exception {
        ArrayList<Empleado> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from empleados");
            rs = st.executeQuery();

            while (rs.next()) {
                Empleado emp = new Empleado(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6), rs.getString(7), rs.getString(8), rs.getInt(9));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    
    public Empleado readUser(String user, String pass) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Empleado obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM empleados WHERE usuario=? and pass=?");
            st.setString(1, user);
            st.setString(2, pass);
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Empleado(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6), rs.getString(7), rs.getString(8), rs.getInt(9));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public Empleado read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Empleado obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM empleados WHERE dni = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Empleado(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6), rs.getString(7), rs.getString(8), rs.getInt(9));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT dni,nombre||' '||apellido as nombre,telefono,direcc,fech_nac,usuario,pass,sup_dni "
                        + "FROM EMPLEADOS WHERE NOMBRE like concat(concat('%',?),'%') OR APELLIDO like concat(concat('%',?),'%')");
                st.setString(1, palabra);
                st.setString(2, palabra);
            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT dni,nombre||' '||apellido as nombre,telefono,direcc,fech_nac,usuario,pass,sup_dni "
                        + "FROM EMPLEADOS WHERE DNI=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[8];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getString(4);
                obj[4] = rs.getDate(5);
                obj[5] = rs.getString(6);
                obj[6] = rs.getString(7);
                obj[7] = rs.getInt(8);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT dni,nombre||' '||apellido as nombre,telefono,direcc,fech_nac,usuario,pass,sup_dni "
                    + "from empleados");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[8];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getString(4);
                obj[4] = rs.getDate(5);
                obj[5] = rs.getString(6);
                obj[6] = rs.getString(7);
                obj[7] = rs.getInt(8);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
