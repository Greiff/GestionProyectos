/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Proyecto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class ProyectoSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Proyecto obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into proyectos values(?,?,current_date,?,?,?,?,?,?,?)");
            st.setInt(1, obj.getId_proy());
            st.setString(2, obj.getDescripcion());
            st.setDate(3, obj.getFech_ini());
            st.setDate(4, obj.getFech_fin());
            st.setString(5, obj.getRequerimientos());
            st.setString(6, obj.getContrato());
            st.setLong(7, obj.getCod_cli());
             st.setInt(8, obj.getCod_muni());
              st.setInt(9, obj.getSup_dni());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Proyecto obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update proyectos set descripcion=?,fech_ini=?,fech_fin=?,requerimientos=?,contrato=?,cod_cli=?,cod_muni=?,sup_dni=? where id_proy=?");
            
            st.setString(1, obj.getDescripcion());
            st.setDate(2, obj.getFech_ini());
            st.setDate(3, obj.getFech_fin());
            st.setString(4, obj.getRequerimientos());
            st.setString(5, obj.getContrato());
            st.setLong(6, obj.getCod_cli());
            st.setInt(7, obj.getCod_muni());
            st.setInt(8, obj.getSup_dni());
            st.setInt(9, obj.getSup_dni());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM proyectos WHERE dni = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Proyecto> readAll() throws Exception {
        ArrayList<Proyecto> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from proyectos");
            rs = st.executeQuery();

            while (rs.next()) {
                Proyecto emp = new Proyecto(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getDate(4), rs.getDate(5), rs.getString(6), rs.getString(7), rs.getInt(8), rs.getInt(9), rs.getInt(10));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }
    

    public Proyecto read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Proyecto obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM proyectos WHERE id_proy = ?");
            st.setInt(1, Integer.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Proyecto(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getDate(4), rs.getDate(5), rs.getString(6), rs.getString(7), rs.getInt(8), rs.getInt(9), rs.getInt(10));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM proyectos WHERE descripcion like concat(concat('%',?),'%')");
                st.setString(1, palabra);
                st.setString(2, palabra);
            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM proyectos WHERE id_proy=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[10];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getDate(4);
                obj[4] = rs.getDate(5);
                obj[5] = rs.getString(6);
                obj[6] = rs.getString(7);
                obj[7] = rs.getInt(8);
                obj[7] = rs.getInt(9);
                obj[7] = rs.getInt(10);
                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT * "
                    + "from proyectos");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[10];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getDate(3);
                obj[3] = rs.getDate(4);
                obj[4] = rs.getDate(5);
                obj[5] = rs.getString(6);
                obj[6] = rs.getString(7);
                obj[7] = rs.getInt(8);
                obj[7] = rs.getInt(9);
                obj[7] = rs.getInt(10);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
