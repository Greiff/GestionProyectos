/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Composicion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class ComposicionSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Composicion obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into composiciones values(?,?,?)");
            st.setFloat(1, obj.getCant_und());
            st.setInt(2, obj.getId_mat());
            st.setInt(3, obj.getId_part());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Composicion obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update composiciones set cant_und=? where id_mat=? and id_part=?");
            st.setFloat(1, obj.getCant_und());
            st.setInt(2, obj.getId_mat());
            st.setInt(3, obj.getId_part());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object keyMat,Object keyPart) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM composiciones WHERE id_mat=? and id_part=?");
            st.setInt(1, Integer.valueOf(keyMat.toString()));
            st.setInt(2, Integer.valueOf(keyPart.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Composicion> readAll() throws Exception {
        ArrayList<Composicion> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from composiciones");
            rs = st.executeQuery();

            while (rs.next()) {
                Composicion emp = new Composicion(rs.getFloat(1), rs.getInt(2), rs.getInt(3));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

    public Composicion read(Object keyMat,Object keyPart) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Composicion obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM composiciones WHERE id_mat=? and id_part=?");
            st.setInt(1, Integer.valueOf(keyMat.toString()));
            st.setInt(2, Integer.valueOf(keyPart.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Composicion(rs.getFloat(1), rs.getInt(2), rs.getInt(3));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> mostrarTodoPart(Object keyPart) throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("select m.id_mat,m.nombre,m.costo_und,c.cant_und,(m.costo_und * c.cant_und)as SUBCOSTO_PART "
                    + "from partidas p, composiciones c ,materiales m  where m.id_mat=c.id_mat and c.id_part=p.id_part and p.id_part=?");
            st.setInt(1, Integer.valueOf(keyPart.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[5];
                obj[0] = rs.getInt(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getFloat(3);
                obj[3] = rs.getFloat(4);
                obj[4] = rs.getFloat(5);
                
                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
