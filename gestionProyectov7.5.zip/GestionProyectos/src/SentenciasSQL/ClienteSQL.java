/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SentenciasSQL;

import Conection.Conection;
import Tablas.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistema
 */
public class ClienteSQL {

    private static final Conection con = Conection.saberEstado();

    public boolean create(Cliente obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("insert into clientes values(?,?,?,?,?)");
            st.setLong(1, obj.getCod_cli());
            st.setString(2, obj.getNombre());
            st.setString(3, obj.getEmail());
            st.setString(4, obj.getTelefono());
            st.setString(5, obj.getDirecc());

            if (st.executeUpdate() > 0) {
                System.out.println("se creo");
                return true;
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean update(Cliente obj) throws Exception {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("update clientes set nombre=?,telefono=?,email=?,direcc=? where cod_cli=?");
            st.setString(1, obj.getNombre());
            st.setString(2, obj.getEmail());
            st.setString(3, obj.getTelefono());
            st.setString(4, obj.getDirecc());
            st.setLong(5, obj.getCod_cli());

            if (st.executeUpdate() > 0) {
                System.out.println("se actualizo");
                return true;
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return false;
    }

    public boolean delete(Object key) {
        PreparedStatement st;
        try {
            st = con.getConn().prepareStatement("DELETE FROM clientes WHERE cod_cli = ?");
            st.setLong(1, Long.valueOf(key.toString()));
            if (st.executeUpdate() > 0) {
                System.out.println("se elimino");
                return true;
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println("no se pudo eliminar " + e);
        } finally {
            con.disconect();
        }
        return false;
    }

    public List<Cliente> readAll() throws Exception {
        ArrayList<Cliente> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;

        try {
            st = con.getConn().prepareStatement("select * from clientes");
            rs = st.executeQuery();

            while (rs.next()) {
                Cliente emp = new Cliente(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                lista.add(emp);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

    public Cliente read(Object key) throws Exception {

        PreparedStatement st;
        ResultSet rs;
        Cliente obj = null;

        try {
            st = con.getConn().prepareStatement("SELECT * FROM clientes WHERE cod_cli = ?");
            st.setLong(1, Long.valueOf(key.toString()));
            rs = st.executeQuery();

            while (rs.next()) {
                obj = new Cliente(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return obj;
    }

    public List<Object[]> buscar(String palabra, boolean esTexto) throws SQLException {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            if (esTexto) {
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM clientes WHERE NOMBRE like concat(concat('%',?),'%')");
                st.setString(1, palabra);

            } else {
                int dni = Integer.valueOf(palabra);
                st = con.getConn().prepareStatement("SELECT * "
                        + "FROM clientes WHERE cod_cli=?");
                st.setInt(1, dni);
            }

            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[5];
                obj[0] = rs.getLong(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getString(4);
                obj[4] = rs.getString(5);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;

    }

    public List<Object[]> mostrarTodo() throws Exception {
        ArrayList<Object[]> lista = new ArrayList();
        PreparedStatement st;
        ResultSet rs;
        try {
            st = con.getConn().prepareStatement("SELECT * "
                    + "from clientes");
            rs = st.executeQuery();

            while (rs.next()) {
                Object[] obj = new Object[5];
                obj[0] = rs.getLong(1);
                obj[1] = rs.getString(2);
                obj[2] = rs.getString(3);
                obj[3] = rs.getString(4);
                obj[4] = rs.getString(5);

                lista.add(obj);
            }

        } catch (SQLException e) {
            throw e;
        } finally {
            con.disconect();
        }
        return lista;
    }

}
