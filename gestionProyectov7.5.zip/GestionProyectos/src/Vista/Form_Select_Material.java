/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;


import GestionProyecto.VistaComposicion;
import GestionProyecto.VistaMaterial;
import Tablas.Composicion;
import Tablas.Material;
import static Vista.Form_Partida.codigoSelectPartida;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Sistema
 */
public class Form_Select_Material extends javax.swing.JFrame {
    
    DefaultTableModel modelo;
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    private int codigoSelect;
    
    /**
     * Creates new form form_rol
     */
    public Form_Select_Material(){
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        modelo= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        // declarar cabecera
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("COSTO UND");
             
        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.tablaUsuario.setModel(modelo);
       
        // se acrtiva mostar por primera vez
        try {
            this.mostrar();
        } catch (Exception ex) {
            Logger.getLogger(Form_Select_Material.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
  
 

        public boolean esNumero(String cadena) {
           boolean resultado;
           try {
               Integer.parseInt(cadena);
               resultado = true;
           } catch (NumberFormatException excepcion) {
               resultado = false;
           }
           return resultado;
        }

        //reduce lasdimenxsiones deun columna para aparentar que no existe
        private void OcultarColumnas(int a){
               tablaUsuario.getColumnModel().getColumn(a).setMaxWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setMinWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setPreferredWidth(0);
        }

       // funcion para imprimir la tabla
        private void mostrar() throws Exception{
             VistaMaterial vista = new VistaMaterial();
             for(int i=0;i<vista.MostrarTodo().size();i++)
             modelo.addRow(vista.MostrarTodo().get(i));
        }

        // funcion para ctualizar tabla 
        private void actualizarTabla() throws Exception{
            modelo.setRowCount(0);
            mostrar();
        }

        private void Buscar(){
            VistaMaterial vista = new VistaMaterial();
            modelo.setRowCount(0);
            boolean esTexto;
            if(this.porNombre.isSelected() == true){
                esTexto=true;    
            }else{
                esTexto=false;   
            }            
            String palabra = textoBuscar.getText();
            
            for(int i=0;i<vista.buscar(palabra,esTexto).size();i++){
                modelo.addRow(vista.buscar(palabra,esTexto).get(i));
            }
        }
        
        private boolean guardarNuevo(){
            VistaComposicion vista = new VistaComposicion();
            if(textoCantPart.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Gestion de Proyectos",0);
            }
            else{
                    Composicion emp = new Composicion(Float.valueOf(textoCantPart.getText()),
                            codigoSelect,
                            Form_Partida.codigoSelectPartida
                            );  
                    vista.GuardarNuevo(emp);
                    return true;
               } 
            return false;
        }


 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        porNombre = new javax.swing.JRadioButton();
        textoBuscar = new javax.swing.JTextField();
        porId = new javax.swing.JRadioButton();
        btnBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaUsuario = new javax.swing.JTable();
        btnAceptar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        textoCantPart = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Seleccionar Material");
        setMinimumSize(new java.awt.Dimension(570, 400));

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(porNombre);
        porNombre.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porNombre.setSelected(true);
        porNombre.setText("Nombre");
        porNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                porNombreActionPerformed(evt);
            }
        });

        textoBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textoBuscarMouseClicked(evt);
            }
        });

        Grupo_Rol.add(porId);
        porId.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porId.setText("ID");

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(porNombre)
                        .addGap(18, 18, 18)
                        .addComponent(porId)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textoBuscar)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar)
                        .addGap(23, 23, 23))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(porNombre)
                    .addComponent(porId))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        tablaUsuario.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaUsuario.getTableHeader().setReorderingAllowed(false);
        tablaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuarioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaUsuario);

        btnAceptar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Cantidad por Und Partida:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(textoCantPart, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAceptar)
                    .addComponent(btnCancelar)
                    .addComponent(jLabel2)
                    .addComponent(textoCantPart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
    boolean verificar;
    verificar = guardarNuevo();
    VistaMaterial vista = new VistaMaterial();
    
    vista.ActualizarDatos();
    if(verificar){
        this.dispose();
        try {
            Form_Partida.actualizarTablaCompo();
            Form_Partida.Limpiar();
            Form_Partida.llenarEspacios(codigoSelectPartida);
        } catch (Exception ex) {
            Logger.getLogger(Form_Select_Material.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }     

    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
    this.dispose();

    }//GEN-LAST:event_btnCancelarActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked

    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void tablaUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuarioMouseClicked
        codigoSelect = Integer.valueOf(tablaUsuario.getValueAt(tablaUsuario.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
    }//GEN-LAST:event_tablaUsuarioMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(porNombre.isSelected()){
            this.Buscar();
        }
        else if(porId.isSelected()&&esNumero(textoBuscar.getText())){
            this.Buscar();
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un ID valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void textoBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textoBuscarMouseClicked

    }//GEN-LAST:event_textoBuscarMouseClicked

    private void porNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_porNombreActionPerformed

    }//GEN-LAST:event_porNombreActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Select_Material().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JRadioButton porId;
    private javax.swing.JRadioButton porNombre;
    private javax.swing.JTable tablaUsuario;
    private javax.swing.JTextField textoBuscar;
    private javax.swing.JTextField textoCantPart;
    // End of variables declaration//GEN-END:variables
}
