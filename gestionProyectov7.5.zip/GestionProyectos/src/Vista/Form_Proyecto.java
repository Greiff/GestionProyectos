/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;


import GestionProyecto.VistaPlano;
import GestionProyecto.VistaPresupuesto;
import GestionProyecto.VistaProyecto;
import Tablas.Proyecto;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.time.LocalDate;


/**
 *
 * @author Sistema
 */
public class Form_Proyecto extends javax.swing.JFrame {
    
    public static DefaultTableModel modelo;
    
    public static DefaultTableModel modeloPresuContrato;
    
    public static DefaultTableModel modeloPlanoContrato;
    
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    public static int codigoSelect;
    public static int codigoSupervisor;
    
    private int codigoSelectPlano;
    private int codigoSelectPresu;
    
    /**
     * Creates new form form_rol
     */
    public Form_Proyecto(){
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        jTabbedPane2.setEnabledAt(1,false);
        
        modelo= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        modeloPlanoContrato= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        modeloPresuContrato= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        // declarar cabecera
        modelo.addColumn("ID PROY");
        modelo.addColumn("DESCRIPCION");
        modelo.addColumn("FECHA CREA");
        modelo.addColumn("FECHA INI");
        modelo.addColumn("FECHA FIN");
        modelo.addColumn("REQUERIMIENTOS");
        modelo.addColumn("CONTRATO");
        modelo.addColumn("COD CLIENTE");
        
        
        modeloPlanoContrato.addColumn("ID");
        modeloPlanoContrato.addColumn("VER");
        modeloPlanoContrato.addColumn("FECHA CREA");
        modeloPlanoContrato.addColumn("AUTOR");
        
        modeloPresuContrato.addColumn("ID");
        modeloPresuContrato.addColumn("VER");
        modeloPresuContrato.addColumn("FECHA CREA");
        modeloPresuContrato.addColumn("IMPORTE TOTAL");

        
        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.tablaUsuario.setModel(modelo);
        
        this.tablaPlanoContrato.setModel(modeloPlanoContrato);
        
        this.tablaPresuContrato.setModel(modeloPresuContrato);
       
        // se acrtiva mostar por primera vez
        try {
            mostrar();
            mostrarPlano();
            mostrarPresupuesto();
        } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.HabilitarBotones();      
  
    }
  
        //limpia los cuadros de texto
        private void Limpiar(){
            this.textDescripcion.setText("");
            this.textContrato.setText("");
            this.textIdProy.setText("");
            textSupervisor.setText("");
            this.textRequerimientos.setText("");
            this.textFechaCrea.setText("");
            this.textFechaIni.setText("");
            this.textFechaFin.setText("");
            textCliente.setText("");
            textTerreno.setText("");
            
        }
        
        // habilita botones dependido del estado de variables nuevo y modificar
        private void HabilitarBotones(){
            if(this.Nuevo || this.Modificar){
                this.btnNuevo.setEnabled(false);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(true);
                this.btnCancelar.setEnabled(true);
                this.btnSalir.setEnabled(false);

            } else{
                this.btnNuevo.setEnabled(true);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(false);
                this.btnCancelar.setEnabled(false);
                this.btnSalir.setEnabled(true);
            }

        }

        public boolean esNumero(String cadena) {
           boolean resultado;
           try {
               Integer.parseInt(cadena);
               resultado = true;
           } catch (NumberFormatException excepcion) {
               resultado = false;
           }
           return resultado;
        }

        //reduce lasdimenxsiones deun columna para aparentar que no existe
        private void OcultarColumnas(int a){
               tablaUsuario.getColumnModel().getColumn(a).setMaxWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setMinWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setPreferredWidth(0);
        }

       // funcion para imprimir la tabla
        public static void mostrar() throws Exception{
             VistaProyecto vista = new VistaProyecto();
             for(int i=0;i<vista.MostrarTodo().size();i++)
             modelo.addRow(vista.MostrarTodo().get(i));
        }
        
        public static void mostrarPlano() throws Exception{
             VistaPlano vista = new VistaPlano();
             for(int i=0;i<vista.MostrarTodoContrato(codigoSelect).size();i++)
             modeloPlanoContrato.addRow(vista.MostrarTodoContrato(codigoSelect).get(i));
        }
        
        public static void mostrarPresupuesto() throws Exception{
             VistaPresupuesto vista = new VistaPresupuesto();
             for(int i=0;i<vista.MostrarTodoContrato(codigoSelect).size();i++)
             modeloPresuContrato.addRow(vista.MostrarTodoContrato(codigoSelect).get(i));
        }

        // funcion para ctualizar tabla 
        public static void actualizarTabla() throws Exception{
            modelo.setRowCount(0);
            modeloPlanoContrato.setRowCount(0);
            modeloPresuContrato.setRowCount(0);
            mostrar();
            mostrarPlano();
            mostrarPresupuesto();

        }

        private void Buscar(){
            VistaProyecto vista = new VistaProyecto();
            modelo.setRowCount(0);
            boolean esTexto;
            if(this.porNombre.isSelected() == true){
                esTexto=true;    
            }else{
                esTexto=false;   
            }            
            String palabra = textoBuscar.getText();
            
            for(int i=0;i<vista.buscar(palabra,esTexto).size();i++){
                modelo.addRow(vista.buscar(palabra,esTexto).get(i));
            }
        }

        private boolean guardarNuevo(){
            VistaProyecto vista = new VistaProyecto();
            
            
            if(textDescripcion.getText().equalsIgnoreCase("")|| textIdProy.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Gestion de Proyectos",0);
            }
            else{
                if(esNumero(textIdProy.getText())){

                    Proyecto emp = new Proyecto(Integer.valueOf(textIdProy.getText()),
                            textDescripcion.getText(),
                            Date.valueOf(textFechaIni.getDate()),
                            Date.valueOf(textFechaFin.getDate()),
                            textRequerimientos.getText(),
                            textContrato.getText(),
                            Integer.valueOf(textCliente.getText()),
                            Integer.valueOf(textTerreno.getText()),
                            Integer.valueOf(textSupervisor.getText())
                    );  
                    vista.GuardarNuevo(emp);
                    this.Limpiar();
                    JOptionPane.showMessageDialog(this, "Usuario Creado.","Sistema de Ventas",1);    
                    return true;
               } 
               else {
                   JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                   return false;
               } 
            }
           return false;         
        }

        private boolean guardarModificado(){
            VistaProyecto vista = new VistaProyecto();
            Proyecto obj;

            if(textDescripcion.getText().equalsIgnoreCase("")|| textIdProy.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Gestion de Proyectos",0);
            }
            else{       
                if(esNumero(textIdProy.getText())){
                    obj = new Proyecto(Integer.valueOf(textIdProy.getText()),
                            textDescripcion.getText(),
                            Date.valueOf(textFechaIni.getDate()),
                            Date.valueOf(textFechaFin.getDate()),
                            textRequerimientos.getText(),
                            textContrato.getText(),
                            Integer.valueOf(textCliente.getText()),
                            Integer.valueOf(textTerreno.getText()),
                            Integer.valueOf(textSupervisor.getText())
                    );

                    vista.GuardarModificado(obj);


                    JOptionPane.showMessageDialog(this, "Usuario Modificado.","Sistema de Ventas",1);
                    return true;
                }
                else{
                    JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                    return false;
                   }
            }
           return false;     
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        porNombre = new javax.swing.JRadioButton();
        textoBuscar = new javax.swing.JTextField();
        porDni = new javax.swing.JRadioButton();
        btnBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaUsuario = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textDescripcion = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        textContrato = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textIdProy = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        textRequerimientos = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textFechaCrea = new com.github.lgooddatepicker.components.DatePicker();
        jLabel11 = new javax.swing.JLabel();
        textSupervisor = new javax.swing.JTextField();
        btnBuscarSup = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        textFechaIni = new com.github.lgooddatepicker.components.DatePicker();
        jLabel13 = new javax.swing.JLabel();
        textFechaFin = new com.github.lgooddatepicker.components.DatePicker();
        btnBuscarTerreno = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaPlanoContrato = new javax.swing.JTable();
        btnEliPlano = new javax.swing.JButton();
        btnAñadirPlano = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaPresuContrato = new javax.swing.JTable();
        btnAñadirPresu = new javax.swing.JButton();
        btnEliPresu = new javax.swing.JButton();
        textTerreno = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textCliente = new javax.swing.JTextField();
        btnBuscarCli = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Proyectos");
        setMinimumSize(new java.awt.Dimension(730, 400));

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(porNombre);
        porNombre.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porNombre.setSelected(true);
        porNombre.setText("Nombre");
        porNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                porNombreActionPerformed(evt);
            }
        });

        textoBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textoBuscarMouseClicked(evt);
            }
        });

        Grupo_Rol.add(porDni);
        porDni.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porDni.setText("DNI");

        btnBuscar.setText("Buscar");
        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(porNombre)
                        .addGap(18, 18, 18)
                        .addComponent(porDni)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textoBuscar)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar)
                        .addGap(23, 23, 23))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(porNombre)
                    .addComponent(porDni))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        tablaUsuario.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaUsuario.getTableHeader().setReorderingAllowed(false);
        tablaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuarioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaUsuario);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        jPanel2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanel2FocusGained(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Empleado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        textDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDescripcionActionPerformed(evt);
            }
        });

        jLabel1.setText("*Descripcion:");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textContratoActionPerformed(evt);
            }
        });

        jLabel3.setText("*Contrato:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textIdProy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdProyActionPerformed(evt);
            }
        });

        jLabel4.setText("*Id Proy:");
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel7.setText("*Terreno:");
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textRequerimientos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textRequerimientosActionPerformed(evt);
            }
        });

        jLabel8.setText("*Requerimientos:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel10.setText("Supervior:");
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textFechaCrea.setEnabled(false);

        jLabel11.setText("*Fecha Crea:");
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textSupervisor.setEditable(false);
        textSupervisor.setEnabled(false);
        textSupervisor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textSupervisorActionPerformed(evt);
            }
        });

        btnBuscarSup.setText("B. Superv");
        btnBuscarSup.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscarSup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarSupActionPerformed(evt);
            }
        });

        jLabel12.setText("*Fecha Ini:");
        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel13.setText("*Fecha Fin:");
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btnBuscarTerreno.setText("B. Terreno");
        btnBuscarTerreno.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscarTerreno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarTerrenoActionPerformed(evt);
            }
        });

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Planos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        tablaPlanoContrato.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaPlanoContrato.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tablaPlanoContrato.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaPlanoContrato.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaPlanoContrato.getTableHeader().setReorderingAllowed(false);
        tablaPlanoContrato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPlanoContratoMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tablaPlanoContrato);

        btnEliPlano.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliPlano.setText("Eliminar");
        btnEliPlano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliPlanoActionPerformed(evt);
            }
        });

        btnAñadirPlano.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAñadirPlano.setText("Añadir");
        btnAñadirPlano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAñadirPlanoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAñadirPlano)
                .addGap(54, 54, 54)
                .addComponent(btnEliPlano)
                .addGap(19, 19, 19))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAñadirPlano)
                    .addComponent(btnEliPlano))
                .addGap(20, 20, 20))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Presupuestos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        tablaPresuContrato.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaPresuContrato.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tablaPresuContrato.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaPresuContrato.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaPresuContrato.getTableHeader().setReorderingAllowed(false);
        tablaPresuContrato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPresuContratoMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablaPresuContrato);

        btnAñadirPresu.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAñadirPresu.setText("Añadir");
        btnAñadirPresu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAñadirPresuActionPerformed(evt);
            }
        });

        btnEliPresu.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliPresu.setText("Eliminar");
        btnEliPresu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliPresuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAñadirPresu)
                .addGap(54, 54, 54)
                .addComponent(btnEliPresu)
                .addGap(34, 34, 34))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAñadirPresu)
                    .addComponent(btnEliPresu))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        textTerreno.setEditable(false);
        textTerreno.setEnabled(false);
        textTerreno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textTerrenoActionPerformed(evt);
            }
        });

        jLabel9.setText("Cliente:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textCliente.setEditable(false);
        textCliente.setEnabled(false);
        textCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textClienteActionPerformed(evt);
            }
        });

        btnBuscarCli.setText("B. Cliente");
        btnBuscarCli.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscarCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarCliActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(textIdProy, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(textDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(1, 1, 1)))
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(textRequerimientos, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(5, 5, 5)
                            .addComponent(textContrato, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(textFechaCrea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(7, 7, 7)
                                .addComponent(textTerreno, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBuscarSup, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarTerreno, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(textCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscarCli, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(textFechaIni, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel13)
                        .addGap(9, 9, 9)
                        .addComponent(textFechaFin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(textSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnBuscarSup))
                                .addGap(8, 8, 8))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(textIdProy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(textDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(btnBuscarTerreno)
                            .addComponent(textTerreno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textFechaIni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textFechaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(textFechaCrea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textContrato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(textRequerimientos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(btnBuscarCli)
                                    .addComponent(textCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(150, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144))
        );

        jTabbedPane2.addTab("Nuevo / Modificar", jPanel2);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Acciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        btnNuevo.setText("Nuevo");
        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnNuevo)
                .addGap(18, 18, 18)
                .addComponent(btnGuardar)
                .addGap(18, 18, 18)
                .addComponent(btnModificar)
                .addGap(18, 18, 18)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addGap(18, 18, 18)
                .addComponent(btnSalir)
                .addContainerGap(159, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        
        Modificar = true; //declaro amodificar activado
        jTabbedPane2.setSelectedIndex(1); // se carga la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones(); // se vuelve a habilitar los botones
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        this.textIdProy.setEnabled(false);
        
        VistaProyecto vista = new VistaProyecto();
        Proyecto obj = new Proyecto();
        obj= vista.recuperarObjeto(codigoSelect); //se recrea el objeto usuario con sus atributos
        // se llena las cajas de texto
        
            this.textDescripcion.setText(obj.getDescripcion());
            this.textContrato.setText(obj.getContrato());
            this.textIdProy.setText(String.valueOf(obj.getId_proy()));
            textSupervisor.setText(String.valueOf(obj.getSup_dni()));
            this.textRequerimientos.setText(obj.getRequerimientos());
            
            Date date1 = obj.getFech_crea();
            Date date2 = obj.getFech_ini();
            Date date3 = obj.getFech_fin();
            LocalDate fechaCrea = date1.toLocalDate();
            LocalDate fechaIni = date2.toLocalDate();
            LocalDate fechaFin = date3.toLocalDate();
            this.textFechaCrea.setDate(fechaCrea);
            this.textFechaIni.setDate(fechaIni);
            this.textFechaFin.setDate(fechaFin);
            
            textCliente.setText(String.valueOf(obj.getCod_cli()));
            textTerreno.setText(String.valueOf(obj.getCod_muni()));
        
        
    
  
    }//GEN-LAST:event_btnModificarActionPerformed

    private void porNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_porNombreActionPerformed
        
    }//GEN-LAST:event_porNombreActionPerformed

    private void textDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDescripcionActionPerformed

    private void textContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textContratoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textContratoActionPerformed

    private void textIdProyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdProyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdProyActionPerformed

    private void textRequerimientosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textRequerimientosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textRequerimientosActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(porNombre.isSelected()){
            this.Buscar(); 
        }
        else if(porDni.isSelected()&&esNumero(textoBuscar.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        boolean verificar;
        if(Modificar) verificar = guardarModificado();//se pone modificar para evitar problemas con nuevo
        else verificar = guardarNuevo();
        
        if(verificar){
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0);
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones 
        }
      
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void jPanel2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel2FocusGained

    }//GEN-LAST:event_jPanel2FocusGained

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo = true; // se activa el nuevo
        jTabbedPane2.setSelectedIndex(1); // se redirecciona a la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones();       
        this.textIdProy.setEnabled(true);
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0); // lleva a la pestaña 1
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        HabilitarBotones(); //se refresca la activacion de botones
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked
  
    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void tablaUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuarioMouseClicked
        codigoSelect = Integer.valueOf(tablaUsuario.getValueAt(tablaUsuario.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
        this.btnModificar.setEnabled(true);
        this.btnEliminar.setEnabled(true);// una vez seleccionado se habilita la tecla modificar
    }//GEN-LAST:event_tablaUsuarioMouseClicked

    private void textoBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textoBuscarMouseClicked
        
    }//GEN-LAST:event_textoBuscarMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        VistaProyecto vista = new VistaProyecto();
        int resp = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este usuario?", "Sistema de Ventas", 0,2);
        int resp2;  
        if(resp==0){
             if(!vista.Eliminar(codigoSelect)){
                 resp2 = JOptionPane.showConfirmDialog(this,"No se puede eliminar el usuario por riesgo de perdida de infomación porque esta relacionado a otra tabla", "Sistema de Ventas",2,2);  
             }      
             try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
             }
             HabilitarBotones();
        }
   
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void textSupervisorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textSupervisorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textSupervisorActionPerformed

    private void btnBuscarSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarSupActionPerformed
        Form_Select_Supervisor ventana = new Form_Select_Supervisor();
        ventana.setVisible(true);
    }//GEN-LAST:event_btnBuscarSupActionPerformed

    private void btnBuscarTerrenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarTerrenoActionPerformed
        Form_Select_Terreno vista = new Form_Select_Terreno();
        vista.setVisible(true);
    }//GEN-LAST:event_btnBuscarTerrenoActionPerformed

    private void textTerrenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textTerrenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textTerrenoActionPerformed

    private void textClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textClienteActionPerformed

    private void btnBuscarCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCliActionPerformed
        Form_Select_Cliente vista = new Form_Select_Cliente();
        vista.setVisible(true);
    }//GEN-LAST:event_btnBuscarCliActionPerformed

    private void tablaPresuContratoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPresuContratoMouseClicked
       codigoSelectPresu = Integer.valueOf(tablaPresuContrato.getValueAt(tablaPresuContrato.getSelectedRow(), 0).toString());
    }//GEN-LAST:event_tablaPresuContratoMouseClicked

    private void tablaPlanoContratoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPlanoContratoMouseClicked
        codigoSelectPlano = Integer.valueOf(tablaPlanoContrato.getValueAt(tablaPlanoContrato.getSelectedRow(), 0).toString());
    }//GEN-LAST:event_tablaPlanoContratoMouseClicked

    private void btnAñadirPresuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAñadirPresuActionPerformed
        Form_Select_Presupuesto vista = new Form_Select_Presupuesto();
        vista.setVisible(true);
    }//GEN-LAST:event_btnAñadirPresuActionPerformed

    private void btnEliPresuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliPresuActionPerformed
        VistaPresupuesto vista = new VistaPresupuesto();
        vista.updateNull(codigoSelectPresu);
         try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
             }
    }//GEN-LAST:event_btnEliPresuActionPerformed

    private void btnEliPlanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliPlanoActionPerformed
        VistaPlano vista = new VistaPlano();
        vista.updateNull(codigoSelectPlano);
         try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Proyecto.class.getName()).log(Level.SEVERE, null, ex);
             }
    }//GEN-LAST:event_btnEliPlanoActionPerformed

    private void btnAñadirPlanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAñadirPlanoActionPerformed
        Form_Select_Plano vista = new Form_Select_Plano();
        vista.setVisible(true);
    }//GEN-LAST:event_btnAñadirPlanoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Proyecto().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnAñadirPlano;
    private javax.swing.JButton btnAñadirPresu;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarCli;
    private javax.swing.JButton btnBuscarSup;
    private javax.swing.JButton btnBuscarTerreno;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliPlano;
    private javax.swing.JButton btnEliPresu;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JRadioButton porDni;
    private javax.swing.JRadioButton porNombre;
    private javax.swing.JTable tablaPlanoContrato;
    private javax.swing.JTable tablaPresuContrato;
    private javax.swing.JTable tablaUsuario;
    public static javax.swing.JTextField textCliente;
    private javax.swing.JTextField textContrato;
    private javax.swing.JTextField textDescripcion;
    private com.github.lgooddatepicker.components.DatePicker textFechaCrea;
    private com.github.lgooddatepicker.components.DatePicker textFechaFin;
    private com.github.lgooddatepicker.components.DatePicker textFechaIni;
    private javax.swing.JTextField textIdProy;
    private javax.swing.JTextField textRequerimientos;
    public static javax.swing.JTextField textSupervisor;
    public static javax.swing.JTextField textTerreno;
    private javax.swing.JTextField textoBuscar;
    // End of variables declaration//GEN-END:variables
}
