/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;


import GestionProyecto.VistaEmpleado;
import Tablas.Empleado;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.time.LocalDate;


/**
 *
 * @author Sistema
 */
public class Form_Empleado extends javax.swing.JFrame {
    
    DefaultTableModel modelo;
    
    private boolean Nuevo = false;
    private boolean Modificar = false;
    private int codigoSelect;
    public static int codigoSupervisor;
    
    /**
     * Creates new form form_rol
     */
    public Form_Empleado(){
        initComponents();
        
        setLocationRelativeTo(null); //centrar ventana
        
        jTabbedPane2.setEnabledAt(1,false);
        
        modelo= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column){ //permite que las celdas no se puedan editar pero si seleccionar
                return false;
            }
        };
        
        // declarar cabecera
        modelo.addColumn("DNI");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("TELEFONO");
        modelo.addColumn("DIRECCION");
        modelo.addColumn("FECHA NAC");
        modelo.addColumn("USER");
        modelo.addColumn("PASS");
        modelo.addColumn("SUPERVISOR");
             
        //transforma la tabla a las caracteristicas mencioandaszx anrtes
        this.tablaUsuario.setModel(modelo);
       
        // se acrtiva mostar por primera vez
        try {
            this.mostrar();
        } catch (Exception ex) {
            Logger.getLogger(Form_Empleado.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.HabilitarBotones();      
  
    }
  
        //limpia los cuadros de texto
        private void Limpiar(){
            this.textNombre.setText("");
            this.textApellido.setText("");
            this.textDni.setText("");
            this.textSupervisor.setText("");
            this.textpassword.setText("");
            this.textTelefono.setText("");
            this.fechaNac.setText("");
            this.textDireccion.setText("");
            this.textUsuario.setText("");
        }
        
        // habilita botones dependido del estado de variables nuevo y modificar
        private void HabilitarBotones(){
            if(this.Nuevo || this.Modificar){
                this.btnNuevo.setEnabled(false);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(true);
                this.btnCancelar.setEnabled(true);
                this.btnSalir.setEnabled(false);

            } else{
                this.btnNuevo.setEnabled(true);
                this.btnModificar.setEnabled(false);
                this.btnEliminar.setEnabled(false);
                this.btnGuardar.setEnabled(false);
                this.btnCancelar.setEnabled(false);
                this.btnSalir.setEnabled(true);
            }

        }

        public boolean esNumero(String cadena) {
           boolean resultado;
           try {
               Integer.parseInt(cadena);
               resultado = true;
           } catch (NumberFormatException excepcion) {
               resultado = false;
           }
           return resultado;
        }

        //reduce lasdimenxsiones deun columna para aparentar que no existe
        private void OcultarColumnas(int a){
               tablaUsuario.getColumnModel().getColumn(a).setMaxWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setMinWidth(0);
               tablaUsuario.getColumnModel().getColumn(a).setPreferredWidth(0);
        }

       // funcion para imprimir la tabla
        private void mostrar() throws Exception{
             VistaEmpleado vista = new VistaEmpleado();
             for(int i=0;i<vista.MostrarTodo().size();i++)
             modelo.addRow(vista.MostrarTodo().get(i));
        }

        // funcion para ctualizar tabla 
        private void actualizarTabla() throws Exception{
            modelo.setRowCount(0);
            mostrar();

        }

        private void Buscar(){
            VistaEmpleado vista = new VistaEmpleado();
            modelo.setRowCount(0);
            boolean esTexto;
            if(this.porNombre.isSelected() == true){
                esTexto=true;    
            }else{
                esTexto=false;   
            }            
            String palabra = textoBuscar.getText();
            
            for(int i=0;i<vista.buscar(palabra,esTexto).size();i++){
                modelo.addRow(vista.buscar(palabra,esTexto).get(i));
            }
        }

        private boolean guardarNuevo(){
            VistaEmpleado vista = new VistaEmpleado();
            
            
            if(textNombre.getText().equalsIgnoreCase("")|| textDni.getText().equalsIgnoreCase("")|| textUsuario.getText().equalsIgnoreCase("")|| textpassword.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Sistema de Gestion de Proyectos",0);
            }
            else{
                if(esNumero(textDni.getText())){

                    Empleado emp = new Empleado(Integer.valueOf(textDni.getText()),
                            textNombre.getText(),
                            textApellido.getText(),
                            textTelefono.getText(),
                            textDireccion.getText(),
                            Date.valueOf(fechaNac.getDate()),
                            textUsuario.getText(),
                            textpassword.getText(),
                            Integer.valueOf(textSupervisor.getText())
                    );  
                    vista.GuardarNuevo(emp);
                    this.Limpiar();
                    JOptionPane.showMessageDialog(this, "Usuario Creado.","Sistema de Ventas",1);    
                    return true;
               } 
               else {
                   JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                   return false;
               } 
            }
           return false;         
        }

        private boolean guardarModificado(){
            VistaEmpleado vista = new VistaEmpleado();
            Empleado obj;

            if(textNombre.getText().equalsIgnoreCase("")|| textDni.getText().equalsIgnoreCase("")|| textUsuario.getText().equalsIgnoreCase("")|| textpassword.getText().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(this, "Faltan campos obligatorios","Gestion de Proyectos",0);
            }
            else{       
                if(esNumero(textDni.getText())){
                    obj = new Empleado(Integer.valueOf(textDni.getText()),
                            textNombre.getText(),
                            textApellido.getText(),
                            textTelefono.getText(),
                            textDireccion.getText(),
                            Date.valueOf(fechaNac.getDate()),
                            textUsuario.getText(),
                            textpassword.getText(),
                            Integer.valueOf(textSupervisor.getText())); 

                    vista.GuardarModificado(obj);


                    JOptionPane.showMessageDialog(this, "Usuario Modificado.","Sistema de Ventas",1);
                    return true;
                }
                else{
                    JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
                    return false;
                   }
            }
           return false;     
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Grupo_Rol = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        porNombre = new javax.swing.JRadioButton();
        textoBuscar = new javax.swing.JTextField();
        porDni = new javax.swing.JRadioButton();
        btnBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaUsuario = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        textApellido = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textDni = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textUsuario = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textpassword = new javax.swing.JTextField();
        textTelefono = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textDireccion = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        fechaNac = new com.github.lgooddatepicker.components.DatePicker();
        jLabel11 = new javax.swing.JLabel();
        textSupervisor = new javax.swing.JTextField();
        btnBuscarSup = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Empleados");
        setMaximumSize(new java.awt.Dimension(750, 450));
        setMinimumSize(new java.awt.Dimension(730, 400));

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Criterios de busqueda", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        Grupo_Rol.add(porNombre);
        porNombre.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porNombre.setSelected(true);
        porNombre.setText("Nombre");
        porNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                porNombreActionPerformed(evt);
            }
        });

        textoBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textoBuscarMouseClicked(evt);
            }
        });

        Grupo_Rol.add(porDni);
        porDni.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        porDni.setText("DNI");

        btnBuscar.setText("Buscar");
        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(porNombre)
                        .addGap(18, 18, 18)
                        .addComponent(porDni)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textoBuscar)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar)
                        .addGap(23, 23, 23))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(porNombre)
                    .addComponent(porDni))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        tablaUsuario.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tablaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tablaUsuario.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tablaUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tablaUsuario.getTableHeader().setReorderingAllowed(false);
        tablaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuarioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaUsuario);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 595, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Buscar", jPanel1);

        jPanel2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanel2FocusGained(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Empleado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        textNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNombreActionPerformed(evt);
            }
        });

        jLabel1.setText("*Nombre:");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textApellidoActionPerformed(evt);
            }
        });

        jLabel3.setText("*Apellido:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDniActionPerformed(evt);
            }
        });

        jLabel4.setText("*DNI:");
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel6.setText("*Usuario:");
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textUsuarioActionPerformed(evt);
            }
        });

        jLabel7.setText("*Contraseña:");
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textpasswordActionPerformed(evt);
            }
        });

        textTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textTelefonoActionPerformed(evt);
            }
        });

        jLabel8.setText("*Teléfono:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textDireccion.setColumns(20);
        textDireccion.setRows(5);
        jScrollPane1.setViewportView(textDireccion);

        jLabel9.setText("*Dirección:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel10.setText("Supervior:");
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel11.setText("*Fech Nac:");
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        textSupervisor.setEditable(false);
        textSupervisor.setEnabled(false);
        textSupervisor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textSupervisorActionPerformed(evt);
            }
        });

        btnBuscarSup.setText("Buscar Supervisor");
        btnBuscarSup.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBuscarSup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarSupActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(6, 6, 6)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(textSupervisor, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBuscarSup, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textDni, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel3))
                                        .addGap(5, 5, 5)
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(textNombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                                            .addComponent(textApellido, javax.swing.GroupLayout.Alignment.LEADING))))
                                .addGap(2, 2, 2)))
                        .addGap(45, 45, 45)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(fechaNac, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textTelefono)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(textUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(textpassword, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fechaNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(99, 99, 99)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBuscarSup)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120))
        );

        jTabbedPane2.addTab("Nuevo / Modificar", jPanel2);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Acciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        btnNuevo.setText("Nuevo");
        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnNuevo)
                .addGap(18, 18, 18)
                .addComponent(btnGuardar)
                .addGap(18, 18, 18)
                .addComponent(btnModificar)
                .addGap(18, 18, 18)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addGap(18, 18, 18)
                .addComponent(btnSalir)
                .addContainerGap(114, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        
        Modificar = true; //declaro amodificar activado
        jTabbedPane2.setSelectedIndex(1); // se carga la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones(); // se vuelve a habilitar los botones
        
        this.textDni.setEnabled(false);
        
        VistaEmpleado vista = new VistaEmpleado();
        Empleado obj = new Empleado();
        obj= vista.recuperarObjeto(codigoSelect); //se recrea el objeto usuario con sus atributos
        // se llena las cajas de texto
        this.textNombre.setText(obj.getNombre());
        this.textApellido.setText(obj.getApellido());    
        this.textDni.setText(String.valueOf(obj.getDni()));
        this.textpassword.setText(obj.getPassword());
        this.textTelefono.setText(obj.getTelefono());

        if(obj.getFechaNac()==null){
            this.fechaNac.setDate(null);
        }   
        else{
            Date date = obj.getFechaNac();
            LocalDate fechNac = date.toLocalDate();
            this.fechaNac.setDate(fechNac);
        }
        this.textDireccion.setText(obj.getDireccion());
        this.textUsuario.setText(obj.getUsuario());
        this.textSupervisor.setText(String.valueOf(obj.getSupDni()));
    }//GEN-LAST:event_btnModificarActionPerformed

    private void porNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_porNombreActionPerformed
        
    }//GEN-LAST:event_porNombreActionPerformed

    private void textNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNombreActionPerformed

    private void textApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textApellidoActionPerformed

    private void textDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDniActionPerformed

    private void textUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textUsuarioActionPerformed

    private void textpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textpasswordActionPerformed

    private void textTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textTelefonoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        if(porNombre.isSelected()){
            this.Buscar(); 
        }
        else if(porDni.isSelected()&&esNumero(textoBuscar.getText())){
           this.Buscar(); 
        }else{
            JOptionPane.showMessageDialog(this, "Ingrese un DNI valido.","Sistema de Ventas",1);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        boolean verificar;
        if(Modificar) verificar = guardarModificado();//se pone modificar para evitar problemas con nuevo
        else verificar = guardarNuevo();
        
        if(verificar){
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0);
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Empleado.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HabilitarBotones(); //se refresca la activacion de botones 
        }
      
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void jPanel2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel2FocusGained

    }//GEN-LAST:event_jPanel2FocusGained

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo = true; // se activa el nuevo
        jTabbedPane2.setSelectedIndex(1); // se redirecciona a la segunda pestaña
        jTabbedPane2.setEnabledAt(1,true);
        jTabbedPane2.setEnabledAt(0,false);
        HabilitarBotones();       
        this.textDni.setEnabled(true);
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        Nuevo = false; // funciona paar ambos por eso cancela ambos
        Modificar = false;
        jTabbedPane2.setEnabledAt(0,true);
        jTabbedPane2.setEnabledAt(1,false);
        jTabbedPane2.setSelectedIndex(0); // lleva a la pestaña 1
        
        this.Limpiar(); // limpia todas los textos con cosas
        
        try { //refresca la tabla con todos los valores
            actualizarTabla();
        } catch (Exception ex) {
            Logger.getLogger(Form_Empleado.class.getName()).log(Level.SEVERE, null, ex);
        }
        HabilitarBotones(); //se refresca la activacion de botones
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked
  
    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void tablaUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuarioMouseClicked
        codigoSelect = Integer.valueOf(tablaUsuario.getValueAt(tablaUsuario.getSelectedRow(), 0).toString()); //guarda el id del usuario de la fila aseleccionada
        this.btnModificar.setEnabled(true);
        this.btnEliminar.setEnabled(true);// una vez seleccionado se habilita la tecla modificar
    }//GEN-LAST:event_tablaUsuarioMouseClicked

    private void textoBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textoBuscarMouseClicked
        
    }//GEN-LAST:event_textoBuscarMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        VistaEmpleado vista = new VistaEmpleado();
        int resp = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este usuario?", "Sistema de Ventas", 0,2);
        int resp2;  
        if(resp==0){
             if(!vista.Eliminar(codigoSelect)){
                 resp2 = JOptionPane.showConfirmDialog(this,"No se puede eliminar el usuario por riesgo de perdida de infomación porque esta relacionado a otra tabla", "Sistema de Ventas",2,2);  
             }      
             try { //refresca la tabla con todos los valores
            actualizarTabla();
             } catch (Exception ex) {
            Logger.getLogger(Form_Empleado.class.getName()).log(Level.SEVERE, null, ex);
             }
             HabilitarBotones();
        }
   
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void textSupervisorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textSupervisorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textSupervisorActionPerformed

    private void btnBuscarSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarSupActionPerformed
        Form_Select_Empleado ventana = new Form_Select_Empleado();
        ventana.setVisible(true);
    }//GEN-LAST:event_btnBuscarSupActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Logeo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Empleado().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grupo_Rol;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarSup;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.github.lgooddatepicker.components.DatePicker fechaNac;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JRadioButton porDni;
    private javax.swing.JRadioButton porNombre;
    private javax.swing.JTable tablaUsuario;
    private javax.swing.JTextField textApellido;
    private javax.swing.JTextArea textDireccion;
    private javax.swing.JTextField textDni;
    private javax.swing.JTextField textNombre;
    public static javax.swing.JTextField textSupervisor;
    private javax.swing.JTextField textTelefono;
    private javax.swing.JTextField textUsuario;
    private javax.swing.JTextField textoBuscar;
    private javax.swing.JTextField textpassword;
    // End of variables declaration//GEN-END:variables
}
