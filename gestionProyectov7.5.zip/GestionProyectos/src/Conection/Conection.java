/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Sistema
 */
public class Conection {
    public static Conection instancia;
    private static Connection conn;
    private static  final String DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static  final String USER ="system";
    private static  final String PASSWORD="admin";
    private static  final String URL= "jdbc:oracle:thin:@localhost:1521:xe";

    public Conection() {
        try{
           Class.forName(DRIVER);
           conn=DriverManager.getConnection(URL, USER,PASSWORD);
           if(conn!= null){
           }
        } catch ( ClassNotFoundException | SQLException e){
            System.out.println("Error al conectar " + e);
        }
    }
    
    public synchronized static Conection saberEstado(){
        if(instancia ==  null){
            instancia = new Conection();
        }
        return instancia;
    }   

    public Connection getConn() {
        return conn;
    }
    
    public void disconect(){
        instancia=null;
        if(instancia==null){
        }
    }
}
