/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;
import java.sql.Date;

public class Plano {
    
    private int id_plano;
    private String version,plano;
    private Date fech_crea;
    private int dni,id_proy;

    public Plano(int id_plano, String version, String plano, Date fech_crea, int dni, int id_proy) {
        this.id_plano = id_plano;
        this.version = version;
        this.plano = plano;
        this.fech_crea = fech_crea;
        this.dni = dni;
        this.id_proy = id_proy;
    }

    public Plano(int id_plano, String version, String plano, int dni) {
        this.id_plano = id_plano;
        this.version = version;
        this.plano = plano;
        this.dni = dni;
    }
    
    

    public Plano(int id_plano, String version, String plano, int dni, int id_proy) {
        this.id_plano = id_plano;
        this.version = version;
        this.plano = plano;
        this.dni = dni;
        this.id_proy = id_proy;
    }

    public Plano() {
    }

    public int getId_plano() {
        return id_plano;
    }

    public void setId_plano(int id_plano) {
        this.id_plano = id_plano;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getId_proy() {
        return id_proy;
    }

    public void setId_proy(int id_proy) {
        this.id_proy = id_proy;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    public Date getFech_crea() {
        return fech_crea;
    }

    public void setFech_crea(Date fech_crea) {
        this.fech_crea = fech_crea;
    }
    
    
    
    
    
}
