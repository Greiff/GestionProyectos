/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;
import java.sql.Date;
/**
 *
 * @author mateo
 */
public class Proyecto {
    private int id_proy;
    private String descripcion;
    private Date fech_crea;    
    private Date fech_ini;
    private Date fech_fin;
    private String requerimientos;
    private String contrato;
    private long cod_cli;
    private int cod_muni;
    private int sup_dni;

    public Proyecto(int id_proy, String descripcion) {
        this.id_proy = id_proy;
        this.descripcion = descripcion;
    }

    public Proyecto(int id_proy, String descripcion, Date fech_crea, Date fech_ini, Date fech_fin, String requerimientos, String contrato, long cod_cli, int cod_muni, int sup_dni) {
        this.id_proy = id_proy;
        this.descripcion = descripcion;
        this.fech_crea = fech_crea;
        this.fech_ini = fech_ini;
        this.fech_fin = fech_fin;
        this.requerimientos = requerimientos;
        this.contrato = contrato;
        this.cod_cli = cod_cli;
        this.cod_muni = cod_muni;
        this.sup_dni = sup_dni;
    }

    public Proyecto(int id_proy, String descripcion, Date fech_ini, Date fech_fin, String requerimientos, String contrato, long cod_cli, int cod_muni, int sup_dni) {
        this.id_proy = id_proy;
        this.descripcion = descripcion;
        this.fech_ini = fech_ini;
        this.fech_fin = fech_fin;
        this.requerimientos = requerimientos;
        this.contrato = contrato;
        this.cod_cli = cod_cli;
        this.cod_muni = cod_muni;
        this.sup_dni = sup_dni;
    }
    
    


    public Proyecto() {
    }

    public int getId_proy() {
        return id_proy;
    }

    public void setId_proy(int id_proy) {
        this.id_proy = id_proy;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFech_ini() {
        return fech_ini;
    }

    public void setFech_ini(Date fech_ini) {
        this.fech_ini = fech_ini;
    }

    public Date getFech_fin() {
        return fech_fin;
    }

    public void setFech_fin(Date fech_fin) {
        this.fech_fin = fech_fin;
    }

    public String getRequerimientos() {
        return requerimientos;
    }

    public void setRequerimientos(String requerimientos) {
        this.requerimientos = requerimientos;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public long getCod_cli() {
        return cod_cli;
    }

    public void setCod_cli(long cod_cli) {
        this.cod_cli = cod_cli;
    }

    public int getCod_muni() {
        return cod_muni;
    }

    public void setCod_muni(int cod_muni) {
        this.cod_muni = cod_muni;
    }

    public int getSup_dni() {
        return sup_dni;
    }

    public void setSup_dni(int sup_dni) {
        this.sup_dni = sup_dni;
    }
    public Date getFech_crea() {
        return fech_crea;
    }

    public void setFech_crea(Date fech_crea) {
        this.fech_crea = fech_crea;
    }
}
