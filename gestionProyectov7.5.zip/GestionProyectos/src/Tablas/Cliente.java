/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author HP
 */
public class Cliente {
    private Long cod_cli;
    private String nombre;
    private String telefono;
    private String email;
    private String direcc;

    public Cliente(Long cod_cli, String nombre, String telefono, String email, String direcc) {
        this.cod_cli = cod_cli;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
        this.direcc = direcc;
    }

    public Cliente() {
    }
    
    

    public Long getCod_cli() {
        return cod_cli;
    }

    public void setCod_cli(Long cod_cli) {
        this.cod_cli = cod_cli;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDirecc() {
        return direcc;
    }

    public void setDirecc(String direcc) {
        this.direcc = direcc;
    }
    
    
    
}
