/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author HP
 */
public class Terreno {

    private int cod_muni;
    private String titular;
    private double area;
    private String tipo;
    

    public Terreno(int cod_muni, String titular, double area, String tipo) {
        this.cod_muni = cod_muni;
        this.titular = titular;
        this.area = area;
        this.tipo = tipo;
    }

    public Terreno() {
    }

    public int getCod_muni() {
        return cod_muni;
    }

    public void setCod_muni(int cod_muni) {
        this.cod_muni = cod_muni;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
        
}

