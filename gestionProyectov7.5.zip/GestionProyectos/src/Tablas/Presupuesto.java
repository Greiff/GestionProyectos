/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;
import java.sql.Date;

/**
 *
 * @author ners_
 */
public class Presupuesto {
    
    private  int id_presu;
    private  String version;
    private  Date fech_crea;
    private float impuesto,importe_total;
    private int id_proy,dni;

    public Presupuesto(int id_presu, String version, Date fech_crea, float impuesto, float importe_total, int id_proy, int dni) {
        this.id_presu = id_presu;
        this.version = version;
        this.fech_crea = fech_crea;
        this.impuesto = impuesto;
        this.importe_total = importe_total;
        this.id_proy = id_proy;
        this.dni = dni;
    }

    public Presupuesto(int id_presu, String version, float impuesto, float importe_total, int id_proy, int dni) {
        this.id_presu = id_presu;
        this.version = version;
        this.impuesto = impuesto;
        this.importe_total = importe_total;
        this.id_proy = id_proy;
        this.dni = dni;
    }

    public Presupuesto(int id_presu, String version, int dni) {
        this.id_presu = id_presu;
        this.version = version;
        this.dni = dni;
    }
    
    

    public Presupuesto() {
    }

    public int getId_presu() {
        return id_presu;
    }

    public void setId_presu(int id_presu) {
        this.id_presu = id_presu;
    }

    public float getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(int impuesto) {
        this.impuesto = impuesto;
    }

    public float getImporte_total() {
        return importe_total;
    }

    public void setImporte_total(int importe_total) {
        this.importe_total = importe_total;
    }

    public int getId_proy() {
        return id_proy;
    }

    public void setId_proy(int id_proy) {
        this.id_proy = id_proy;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getFech_crea() {
        return fech_crea;
    }

    public void setFech_crea(Date fech_crea) {
        this.fech_crea = fech_crea;
    }
    
    
    
}
