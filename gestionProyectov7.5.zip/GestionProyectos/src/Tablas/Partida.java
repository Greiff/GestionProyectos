/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author mateo
 */
public class Partida {
    private int id_part;
    private float costo_metro;
    private String nombre;
    private int id_cap;

    public Partida(int id_part, float costo_metro, String nombre, int id_cap) {
        this.id_part = id_part;
        this.costo_metro = costo_metro;
        this.nombre = nombre;
        this.id_cap = id_cap;
    }

    public Partida() {
    }

    public int getId_part() {
        return id_part;
    }

    public void setId_part(int id_part) {
        this.id_part = id_part;
    }

    public float getCosto_metro() {
        return costo_metro;
    }

    public void setCosto_metro(float costo_metro) {
        this.costo_metro = costo_metro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId_cap() {
        return id_cap;
    }

    public void setId_cap(int id_cap) {
        this.id_cap = id_cap;
    }
    
}
