/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author mateo
 */
public class Composicion {
    private float cant_und;
    private int id_mat;
    private int id_part;
    
    public Composicion(float cant_und, int id_mat, int id_part) {
        this.cant_und = cant_und;
        this.id_mat = id_mat;
        this.id_part = id_part;
    }

    public Composicion() {
    }

    public float getCant_und() {
        return cant_und;
    }

    public void setCant_und(float cant_und) {
        this.cant_und = cant_und;
    }

    public int getId_mat() {
        return id_mat;
    }

    public void setId_mat(int id_mat) {
        this.id_mat = id_mat;
    }

    public int getId_part() {
        return id_part;
    }

    public void setId_part(int id_part) {
        this.id_part = id_part;
    }
    
}
