/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author ners_
 */
public class Detalle_Partida {
    private float  metraje;
    private float costo_parcial;
    private  int id_part;
    private int  id_presu;

    public Detalle_Partida(float metraje, float costo_parcial, int id_part, int id_presu) {
        this.metraje = metraje;
        this.costo_parcial = costo_parcial;
        this.id_part = id_part;
        this.id_presu = id_presu;
    }

    public Detalle_Partida(float metraje, int id_part, int id_presu) {
        this.metraje = metraje;
        this.id_part = id_part;
        this.id_presu = id_presu;
    }


    public Detalle_Partida() {
    }

    public float getMetraje() {
        return metraje;
    }

    public void setMetraje(int metraje) {
        this.metraje = metraje;
    }

    public float getCosto_parcial() {
        return costo_parcial;
    }

    public void setCosto_parcial(float costo_parcial) {
        this.costo_parcial = costo_parcial;
    }

    public int getId_part() {
        return id_part;
    }

    public void setId_part(int id_part) {
        this.id_part = id_part;
    }

    public int getId_presu() {
        return id_presu;
    }

    public void setId_presu(int id_presu) {
        this.id_presu = id_presu;
    }
            
}
