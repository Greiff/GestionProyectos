/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;



/**
 *
 * @author HP
 */
public class Material {
   
    
    private int id_mat;
    private String nombre;
    private double costo_und;

    public Material(int id_mat, String nombre, double costo_und) {
        this.id_mat = id_mat;
        this.nombre = nombre;
        this.costo_und = costo_und;
    }

    public Material() {
    }
    
    

    public int getId_mat() {
        return id_mat;
    }

    public void setId_mat(int id_mat) {
        this.id_mat = id_mat;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCosto_und() {
        return costo_und;
    }

    public void setCosto_und(double costo_und) {
        this.costo_und = costo_und;
    }
    
    
    
}
