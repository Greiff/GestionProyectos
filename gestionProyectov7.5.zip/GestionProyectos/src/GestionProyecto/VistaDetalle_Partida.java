/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.Detalle_PartidaSQL;
import Tablas.Detalle_Partida;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaDetalle_Partida {

    public VistaDetalle_Partida() {
    }
    
    
    public List<Object[]> MostrarTodoPart(int codigo) throws Exception{       
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodoPresu(codigo);
        return lista;
    }
    
    public boolean GuardarNuevo(Detalle_Partida obj){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaDetalle_Partida.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Detalle_Partida obj){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaDetalle_Partida.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Detalle_Partida recuperarObjeto (int codigoPart,int codigoPresu){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL();
        Detalle_Partida obj = new Detalle_Partida();
        
        try {
            obj = metodo.read(codigoPart,codigoPresu);
        } catch (Exception ex) {
            Logger.getLogger(VistaDetalle_Partida.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigoPart,int codigoPresu){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL(); 
        return metodo.delete(codigoPart,codigoPresu);   
    }
    
    public boolean EliminarTotal (int codigoPresu){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL(); 
        return metodo.deleteAll(codigoPresu);   
    }
    
    public void ActualizarDatosPresu(Object key){
        Detalle_PartidaSQL metodo =new Detalle_PartidaSQL(); 
        metodo.actualizarDatosPresu(key);
    }
    
    
}
