/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.ComposicionSQL;
import Tablas.Composicion;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaComposicion {

    public VistaComposicion() {
    }
    
    
    public List<Object[]> MostrarTodoPart(int codigoPart) throws Exception{       
        ComposicionSQL metodo =new ComposicionSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodoPart(codigoPart);
        return lista;
    }
    
    public boolean GuardarNuevo(Composicion obj){
        ComposicionSQL metodo =new ComposicionSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaComposicion.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Composicion obj){
        ComposicionSQL metodo =new ComposicionSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaComposicion.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Composicion recuperarObjeto (int codigoMat,int codigoPart){
        ComposicionSQL metodo =new ComposicionSQL();
        Composicion obj = new Composicion();
        
        try {
            obj = metodo.read(codigoMat,codigoPart);
        } catch (Exception ex) {
            Logger.getLogger(VistaComposicion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigoMat,int codigoPart){
        ComposicionSQL metodo =new ComposicionSQL(); 
        return metodo.delete(codigoMat,codigoPart);   
    }
    
    
    
}
