/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.PartidaSQL;
import Tablas.Partida;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaPartida {

    public VistaPartida() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        PartidaSQL metodo =new PartidaSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaPartida.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        PartidaSQL metodo =new PartidaSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Partida obj){
        PartidaSQL metodo =new PartidaSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPartida.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Partida obj){
        PartidaSQL metodo =new PartidaSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPartida.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Partida recuperarObjeto (int codigo){
        PartidaSQL metodo =new PartidaSQL();
        Partida obj = new Partida();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaPartida.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        PartidaSQL metodo =new PartidaSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
