/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.ClienteSQL;
import Tablas.Cliente;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaCliente {

    public VistaCliente() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        ClienteSQL metodo =new ClienteSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        ClienteSQL metodo =new ClienteSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Cliente obj){
        ClienteSQL metodo =new ClienteSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaCliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Cliente obj){
        ClienteSQL metodo =new ClienteSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaCliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Cliente recuperarObjeto (Long codigo){
        ClienteSQL metodo =new ClienteSQL();
        Cliente obj = new Cliente();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (Long codigo){
        ClienteSQL metodo =new ClienteSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
