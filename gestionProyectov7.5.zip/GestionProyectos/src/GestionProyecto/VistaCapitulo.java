/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.CapituloSQL;
import Tablas.Capitulo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaCapitulo {

    public VistaCapitulo() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        CapituloSQL metodo =new CapituloSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaCapitulo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        CapituloSQL metodo =new CapituloSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Capitulo obj){
        CapituloSQL metodo =new CapituloSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaCapitulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Capitulo obj){
        CapituloSQL metodo =new CapituloSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaCapitulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Capitulo recuperarObjeto (int codigo){
        CapituloSQL metodo =new CapituloSQL();
        Capitulo obj = new Capitulo();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaCapitulo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        CapituloSQL metodo =new CapituloSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
