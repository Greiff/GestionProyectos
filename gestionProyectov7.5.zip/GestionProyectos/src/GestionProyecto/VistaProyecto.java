/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;

import SentenciasSQL.ProyectoSQL;
import Tablas.Proyecto;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaProyecto {

    public VistaProyecto() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        ProyectoSQL metodo =new ProyectoSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        ProyectoSQL metodo =new ProyectoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Proyecto obj){
        ProyectoSQL metodo =new ProyectoSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaProyecto.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Proyecto obj){
        ProyectoSQL metodo =new ProyectoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaProyecto.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Proyecto recuperarObjeto (int codigo){
        ProyectoSQL metodo =new ProyectoSQL();
        Proyecto obj = new Proyecto();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        ProyectoSQL metodo =new ProyectoSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
