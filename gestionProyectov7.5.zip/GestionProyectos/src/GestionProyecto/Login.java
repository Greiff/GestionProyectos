/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;

import SentenciasSQL.EmpleadoSQL;
import Tablas.Empleado;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class Login {

    public Login() {
    }
    
    public Empleado recuperarUsuario (String user,String pass){
        EmpleadoSQL metodo =new EmpleadoSQL();
        Empleado obj = new Empleado();
        
        try {
            obj = metodo.readUser(user,pass);
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
     
    public boolean VerificarUsuario(String user,String pass){
       EmpleadoSQL metodo =new EmpleadoSQL();
        List<Empleado> lista = new ArrayList();
        
        try {
            lista = metodo.readAll();
        } catch (Exception ex) {
            System.out.println("Hubo excepcion: " + ex);
        }
        for (int i=0;i<lista.size();i++){
            if(user.equalsIgnoreCase(lista.get(i).getUsuario())
                    && pass.equalsIgnoreCase(lista.get(i).getPassword())){
                return true;
            }
        }     
        return false;
    }
}
