/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;

import SentenciasSQL.PresupuestoSQL;
import Tablas.Presupuesto;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaPresupuesto {

    public VistaPresupuesto() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        PresupuestoSQL metodo =new PresupuestoSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        PresupuestoSQL metodo =new PresupuestoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public List<Object[]> MostrarTodoContrato(Object key) throws Exception{       
        PresupuestoSQL metodo =new PresupuestoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodoContrato(key);
        return lista;
    }
    
    public boolean GuardarNuevo(Presupuesto obj){
        PresupuestoSQL metodo =new PresupuestoSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Presupuesto obj){
        PresupuestoSQL metodo =new PresupuestoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public boolean updateContrato(int keyPresu,int keyProy){
        PresupuestoSQL metodo =new PresupuestoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.updateContrato(keyPresu,keyProy);
            } catch (Exception ex) {
                Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public boolean updateNull(int keyPresu){
        PresupuestoSQL metodo =new PresupuestoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.updateNull(keyPresu);
            } catch (Exception ex) {
                Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Presupuesto recuperarObjeto (int codigo){
        PresupuestoSQL metodo =new PresupuestoSQL();
        Presupuesto obj = new Presupuesto();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        PresupuestoSQL metodo =new PresupuestoSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
