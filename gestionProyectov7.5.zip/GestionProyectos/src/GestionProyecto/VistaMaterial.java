/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.MaterialSQL;
import Tablas.Material;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaMaterial {

    public VistaMaterial() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        MaterialSQL metodo =new MaterialSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaMaterial.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        MaterialSQL metodo =new MaterialSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Material obj){
        MaterialSQL metodo =new MaterialSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaMaterial.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Material obj){
        MaterialSQL metodo =new MaterialSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaMaterial.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Material recuperarObjeto (int codigo){
        MaterialSQL metodo =new MaterialSQL();
        Material obj = new Material();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaMaterial.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        MaterialSQL metodo =new MaterialSQL(); 
        return metodo.delete(codigo);   
    }
    
    public void ActualizarDatos(){
        MaterialSQL metodo =new MaterialSQL(); 
        metodo.actualizarDatos();
    }
    
    
}
