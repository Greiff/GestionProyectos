/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.PlanoSQL;
import Tablas.Plano;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaPlano {

    public VistaPlano() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        PlanoSQL metodo =new PlanoSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        PlanoSQL metodo =new PlanoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public List<Object[]> MostrarTodoContrato(Object key) throws Exception{       
        PlanoSQL metodo =new PlanoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodoContrato(key);
        return lista;
    }
    
    
    
    public boolean GuardarNuevo(Plano obj){
        PlanoSQL metodo =new PlanoSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarNuevoSinProy(Plano obj){
        PlanoSQL metodo =new PlanoSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.createSinProy(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Plano obj){
        PlanoSQL metodo =new PlanoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public boolean updateContrato(int keyPlano,int keyProy){
        PlanoSQL metodo =new PlanoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.updateContrato(keyPlano,keyProy);
            } catch (Exception ex) {
                Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public boolean updateNull(int keyPlano){
        PlanoSQL metodo =new PlanoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.updateNull(keyPlano);
            } catch (Exception ex) {
                Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Plano recuperarObjeto (int codigo){
        PlanoSQL metodo =new PlanoSQL();
        Plano obj = new Plano();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaPlano.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        PlanoSQL metodo =new PlanoSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
