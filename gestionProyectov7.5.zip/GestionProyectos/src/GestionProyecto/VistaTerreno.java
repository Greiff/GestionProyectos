/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestionProyecto;



import SentenciasSQL.TerrenoSQL;
import Tablas.Terreno;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistema
 */
public class VistaTerreno {

    public VistaTerreno() {
    }
    
    public List<Object[]> buscar(String palabra,boolean esTexto){
        
        TerrenoSQL metodo =new TerrenoSQL();
        List<Object[]> lista = new ArrayList();
        
        try {
            lista = metodo.buscar(palabra,esTexto);
        } catch (SQLException ex) {
            Logger.getLogger(VistaTerreno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<Object[]> MostrarTodo() throws Exception{       
        TerrenoSQL metodo =new TerrenoSQL();     
        List<Object[]> lista = new ArrayList();      
        lista = metodo.mostrarTodo();
        return lista;
    }
    
    public boolean GuardarNuevo(Terreno obj){
        TerrenoSQL metodo =new TerrenoSQL();
        boolean verificar = false;
   
            try {
                verificar = metodo.create(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaTerreno.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return verificar;
    }
    
    public boolean GuardarModificado(Terreno obj){
        TerrenoSQL metodo =new TerrenoSQL();
        boolean verificar = false;
            try {
                verificar = metodo.update(obj);
            } catch (Exception ex) {
                Logger.getLogger(VistaTerreno.class.getName()).log(Level.SEVERE, null, ex);
            }
        return verificar;
    }
    
    public Terreno recuperarObjeto (int codigo){
        TerrenoSQL metodo =new TerrenoSQL();
        Terreno obj = new Terreno();
        
        try {
            obj = metodo.read(codigo);
        } catch (Exception ex) {
            Logger.getLogger(VistaTerreno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }
    
    public boolean Eliminar (int codigo){
        TerrenoSQL metodo =new TerrenoSQL(); 
        return metodo.delete(codigo);   
    }
    
    
    
}
